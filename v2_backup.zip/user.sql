INSERT INTO `user`(`id`, `icon`, `password`, `email`, `name`, `bio`) VALUES (1, NULL, 'caojinkun111', '627335629@qq.com', 'cjk', NULL);
INSERT INTO `user`(`id`, `icon`, `password`, `email`, `name`, `bio`) VALUES (2, NULL, '123', 'clivehaha@outlook.com', 'zjh', 'try');
INSERT INTO `user`(`id`, `icon`, `password`, `email`, `name`, `bio`) VALUES (3, NULL, 'a1', 'zmh@sjtu.cn', 'zmh', NULL);
INSERT INTO `user`(`id`, `icon`, `password`, `email`, `name`, `bio`) VALUES (7, NULL, 'caojinkun1234', 'herodan1023@gmail.com', 'caojinkun', NULL);
INSERT INTO `user`(`id`, `icon`, `password`, `email`, `name`, `bio`) VALUES (8, NULL, '1234', 'update', 'test-user', 'new bio');
INSERT INTO `user`(`id`, `icon`, `password`, `email`, `name`, `bio`) VALUES (9, NULL, '123', 'test-email1', 'test-user1', NULL);
INSERT INTO `user`(`id`, `icon`, `password`, `email`, `name`, `bio`) VALUES (10, NULL, '1q', 'qqq@q.q', 'qqq', NULL);
INSERT INTO `user`(`id`, `icon`, `password`, `email`, `name`, `bio`) VALUES (11, NULL, 'yh1', '123@123.com', 'XPandora', NULL);
